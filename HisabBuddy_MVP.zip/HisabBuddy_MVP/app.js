// Beginner-friendly HisabBuddy frontend.
// Paste your Supabase project URL and anon/public key below. Never put a service_role key here.
const SUPABASE_URL = "PASTE_YOUR_SUPABASE_PROJECT_URL_HERE";
const SUPABASE_ANON_KEY = "PASTE_YOUR_SUPABASE_ANON_KEY_HERE";
const configured = SUPABASE_URL.startsWith("https://") && !SUPABASE_URL.includes("PASTE_") && !SUPABASE_ANON_KEY.includes("PASTE_");
const client = configured ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;
const $ = id => document.getElementById(id);
let currentUser = null;
let cachedTransactions = [];

function money(value){return new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR",maximumFractionDigits:2}).format(Number(value||0));}
function message(text, type="notice"){const box=$("message");box.className="notice "+(type==="error"?"error":type==="success"?"success":"");box.textContent=text;box.classList.remove("hidden");}
function clearMessage(){$("message").classList.add("hidden");}
function showSignedIn(user){currentUser=user;$("authPanel").classList.add("hidden");$("appPanel").classList.remove("hidden");$("logoutBtn").classList.remove("hidden");$("configNotice").classList.add("hidden");loadTransactions();}
function showSignedOut(){$("authPanel").classList.remove("hidden");$("appPanel").classList.add("hidden");$("logoutBtn").classList.add("hidden");currentUser=null;}
async function runAuth(kind){
  clearMessage();
  if(!client){message("First configure Supabase URL and anon key in app.js, then run the SQL setup from README.md.","error");return;}
  const email=$("authEmail").value.trim(), password=$("authPassword").value;
  if(!email||!password){message("Enter your email and password.","error");return;}
  try{
    const result=kind==="signup"?await client.auth.signUp({email,password}):await client.auth.signInWithPassword({email,password});
    if(result.error)throw result.error;
    if(kind==="signup"&&!result.data.session){message("Account created. Check your email to confirm it, then sign in.","success");return;}
    if(result.data.user)showSignedIn(result.data.user);
    message(kind==="signup"?"Account created.":"Signed in successfully.","success");
  }catch(e){message(e.message||"Authentication failed.","error");}
}
$("signupBtn").addEventListener("click",()=>runAuth("signup"));
$("loginBtn").addEventListener("click",()=>runAuth("login"));
$("logoutBtn").addEventListener("click",async()=>{if(client)await client.auth.signOut();showSignedOut();});

$("txForm").addEventListener("submit",async event=>{
  event.preventDefault();clearMessage();
  if(!client||!currentUser){message("Please configure the database and sign in first.","error");return;}
  const payload={
    p_other_email:$("otherEmail").value.trim().toLowerCase(),
    p_direction:$("direction").value,
    p_amount:Number($("amount").value),
    p_category:$("category").value,
    p_reason:$("reason").value.trim(),
    p_due_date:$("dueDate").value||null
  };
  if(!Number.isFinite(payload.p_amount)||payload.p_amount<=0){message("Enter an amount greater than zero.","error");return;}
  try{
    const {error}=await client.rpc("create_shared_transaction",payload);
    if(error)throw error;
    $("txForm").reset();message("Transaction saved and shared with the other account.","success");await loadTransactions();
  }catch(e){message(e.message||"Could not save transaction. Check the other person's registered email.","error");}
});

async function loadTransactions(){
  if(!client||!currentUser)return;
  $("transactions").innerHTML='<div class="empty">Loading…</div>';
  try{
    const {data,error}=await client.from("transactions").select("*, confirmations(user_id,confirmed_at), repayments(id,amount,note,created_at,created_by)").order("created_at",{ascending:false});
    if(error)throw error;
    cachedTransactions=data||[];renderTransactions();renderSummary();
  }catch(e){$("transactions").innerHTML="";message("Could not load transactions: "+(e.message||"unknown error"),"error");}
}
function renderSummary(){
  let sent=0,received=0,lent=0,borrowed=0;
  for(const t of cachedTransactions){
    if(t.payer_id===currentUser.id)sent+=Number(t.amount);else received+=Number(t.amount);
    if(t.category==="Loan"){
      const paid=(t.repayments||[]).reduce((s,r)=>s+Number(r.amount),0);
      const left=Math.max(0,Number(t.amount)-paid);
      if(t.payer_id===currentUser.id)lent+=left;else borrowed+=left;
    }
  }
  $("sentTotal").textContent=money(sent);$("receivedTotal").textContent=money(received);$("loanTotal").textContent=money(lent)+" / "+money(borrowed);
}
function renderTransactions(){
  const host=$("transactions");
  if(!cachedTransactions.length){host.innerHTML='<div class="empty">No transactions yet. Add your first deal above.</div>';return;}
  host.innerHTML="";
  for(const t of cachedTransactions){
    const isPayer=t.payer_id===currentUser.id;
    const other=isPayer?t.receiver_email:t.payer_email;
    const confirmations=t.confirmations||[];
    const mine=confirmations.some(c=>c.user_id===currentUser.id);
    const theirs=confirmations.some(c=>c.user_id!==(currentUser.id));
    const repaid=(t.repayments||[]).reduce((s,r)=>s+Number(r.amount),0);
    const remaining=Math.max(0,Number(t.amount)-repaid);
    const card=document.createElement("article");card.className="transaction";
    const head=document.createElement("div");head.className="txhead";
    const left=document.createElement("div");
    left.innerHTML=`<strong>${escapeHtml(t.reason)}</strong><div class="muted">${isPayer?"You paid":"You received"} • Other party: ${escapeHtml(other||"account")} • ${new Date(t.created_at).toLocaleDateString("en-IN")}</div><span class="tag">${escapeHtml(t.category)}</span><span class="tag">${isPayer?"You → other":"Other → you"}</span>`;
    const right=document.createElement("div");right.className="amount";right.textContent=money(t.amount);
    head.append(left,right);card.append(head);
    const meta=document.createElement("div");meta.className="txmeta";
    const statusMine=mine?"Confirmed by you":"Not confirmed by you";
    const statusOther=theirs?"Confirmed by other party":"Waiting for other party";
    meta.innerHTML=`<div><b>Your confirmation:</b> <span class="tag ${mine?"confirmed":"pending"}">${statusMine}</span></div><div><b>Other confirmation:</b> <span class="tag ${theirs?"confirmed":"pending"}">${statusOther}</span></div><div><b>Repayments recorded:</b> ${money(repaid)}</div><div><b>Remaining amount:</b> ${money(remaining)}</div>${t.due_date?`<div><b>Due date:</b> ${escapeHtml(t.due_date)}</div>`:""}`;
    card.append(meta);
    const actions=document.createElement("div");actions.className="actions";
    if(!mine){const b=document.createElement("button");b.textContent="Confirm details";b.addEventListener("click",()=>confirmTransaction(t.id));actions.append(b);}
    if(t.category==="Loan"&&remaining>0.00001){const b=document.createElement("button");b.className="secondary";b.textContent="Add repayment";b.addEventListener("click",()=>addRepayment(t.id,remaining));actions.append(b);}
    const hist=document.createElement("div");hist.className="small muted";hist.style.marginTop="10px";
    if((t.repayments||[]).length){hist.textContent="Repayment history: "+t.repayments.map(r=>`${money(r.amount)}${r.note?" — "+r.note:""} (${new Date(r.created_at).toLocaleDateString("en-IN")})`).join(" • ");}else{hist.textContent="No repayments recorded yet.";}
    card.append(actions,hist);host.append(card);
  }
}
function escapeHtml(value){return String(value??"").replace(/[&<>"']/g,ch=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));}
async function confirmTransaction(id){
  try{const {error}=await client.from("confirmations").upsert({transaction_id:id,user_id:currentUser.id},{onConflict:"transaction_id,user_id"});if(error)throw error;message("Your confirmation has been recorded.","success");await loadTransactions();}
  catch(e){message(e.message||"Could not confirm this transaction.","error");}
}
async function addRepayment(id,remaining){
  const raw=prompt(`Enter repayment amount in ₹ (remaining: ${remaining.toFixed(2)}):`);
  if(raw===null)return;
  const amount=Number(raw);if(!Number.isFinite(amount)||amount<=0||amount>remaining+0.00001){message("Enter a valid amount no greater than the remaining balance.","error");return;}
  const note=prompt("Optional note (e.g. returned by UPI):")||"";
  try{const {error}=await client.from("repayments").insert({transaction_id:id,amount,note:note.trim()||null,created_by:currentUser.id});if(error)throw error;message("Repayment recorded for both participants.","success");await loadTransactions();}
  catch(e){message(e.message||"Could not add repayment.","error");}
}
async function init(){
  if(!configured)return;
  $("configNotice").classList.add("hidden");
  const {data:{session}}=await client.auth.getSession();
  if(session?.user)showSignedIn(session.user);
  client.auth.onAuthStateChange((_event,session)=>{if(session?.user)showSignedIn(session.user);else showSignedOut();});
}
init();
