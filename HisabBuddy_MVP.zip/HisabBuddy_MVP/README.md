# HisabBuddy MVP (beginner-friendly)

This starter project is a small website for a shared money ledger. It supports:
- email/password accounts through Supabase Auth
- manual transaction entry with person, amount, reason, category and optional due date
- shared transaction history for both participants
- each participant confirming their own details
- repayments recorded as separate entries, with remaining balance shown
- basic totals for sent, received, and outstanding loans

## Important limitations
This is an MVP starter, not a bank or payment processor. Entries are manually recorded and are not proof that a payment actually happened. The UI is a prototype and should be security-reviewed before real financial use. It currently treats every repayment attached to a transaction as reducing the displayed remaining amount; use the Loan category only for loan balances. Both participants need their own HisabBuddy account.

## Setup (about 15–25 minutes)
1. Create a project at https://supabase.com/ and open its SQL Editor.
2. Open `supabase_setup.sql`, copy the whole file into a new SQL query, and click Run.
3. In Supabase, open Project Settings / API (or Connect) and copy the Project URL and anon/public key. Never use the `service_role` key in a browser.
4. Open `app.js` in a text editor and replace:
   - `PASTE_YOUR_SUPABASE_PROJECT_URL_HERE`
   - `PASTE_YOUR_SUPABASE_ANON_KEY_HERE`
5. In Supabase Authentication settings, set the site URL for your eventual hosted site. During local testing, use the local development URL you choose. Email confirmation settings affect signup: if confirmation is enabled, check your email before signing in.
6. Run a local static server from this folder. If Python is installed, open a terminal in this folder and run:
   `python -m http.server 8000`
   Then open `http://localhost:8000` in your browser.
   (Do not just double-click the HTML file; a local server is more reliable.)
7. Create two accounts using two email addresses. Sign in as person A and create a transaction using person B's registered email. Sign out and sign in as B to see and confirm it. Add a repayment on a Loan transaction and check the remaining balance from both accounts.

## Files
- `index.html` — page layout
- `app.js` — browser logic and Supabase connection
- `supabase_setup.sql` — database tables, access policies and transaction creation function

## MVP implementation plan
Phase 1: Configure Supabase, test sign-up/sign-in, and create two test accounts.
Phase 2: Test shared transaction creation, confirmation by each side, and partial repayments.
Phase 3: Deploy the static website (e.g. Netlify or Vercel) and configure its URL in Supabase Auth.
Phase 4: Before real use, add password reset, user-friendly invitations, receipts, export/backup, disputes/correction history, repayment validation on the server, and security testing.

## Security basics
- Never store UPI PINs, card PINs, banking passwords, or OTPs.
- Keep the anon/public key only in the browser; never expose the service-role key.
- Enable Row Level Security and test access using two separate accounts.
- Use fake/test transactions until the security and business rules have been reviewed.
