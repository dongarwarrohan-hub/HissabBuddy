-- HisabBuddy MVP database setup for Supabase
-- Paste the WHOLE file into Supabase > SQL Editor > New query > Run.
-- This uses Supabase Auth for accounts and Row Level Security for participant-only access.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text unique not null,
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, email)
  values (new.id, lower(new.email))
  on conflict (id) do update set email = excluded.email;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert or update of email on auth.users
for each row execute procedure public.handle_new_user();

-- Backfill any accounts that already existed before this script was run.
insert into public.profiles (id, email)
select id, lower(email) from auth.users where email is not null
on conflict (id) do update set email = excluded.email;

create table if not exists public.transactions (
  id uuid primary key default gen_random_uuid(),
  payer_id uuid not null references auth.users(id),
  receiver_id uuid not null references auth.users(id),
  payer_email text not null,
  receiver_email text not null,
  amount numeric(12,2) not null check (amount > 0),
  category text not null check (category in ('Loan','Repayment','Shared expense','Gift','Purchase','Other')),
  reason text not null check (length(trim(reason)) between 1 and 240),
  due_date date,
  created_by uuid not null references auth.users(id) default auth.uid(),
  created_at timestamptz not null default now(),
  check (payer_id <> receiver_id)
);

create table if not exists public.confirmations (
  transaction_id uuid not null references public.transactions(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  confirmed_at timestamptz not null default now(),
  primary key (transaction_id, user_id)
);

create table if not exists public.repayments (
  id uuid primary key default gen_random_uuid(),
  transaction_id uuid not null references public.transactions(id) on delete cascade,
  amount numeric(12,2) not null check (amount > 0),
  note text,
  created_by uuid not null references auth.users(id) default auth.uid(),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.transactions enable row level security;
alter table public.confirmations enable row level security;
alter table public.repayments enable row level security;

drop policy if exists "Users can read own profile" on public.profiles;
create policy "Users can read own profile" on public.profiles for select to authenticated using (id = auth.uid());

drop policy if exists "Participants can read transactions" on public.transactions;
create policy "Participants can read transactions" on public.transactions for select to authenticated
using (payer_id = auth.uid() or receiver_id = auth.uid());

drop policy if exists "Participants can read confirmations" on public.confirmations;
create policy "Participants can read confirmations" on public.confirmations for select to authenticated
using (exists (select 1 from public.transactions t where t.id = transaction_id and (t.payer_id = auth.uid() or t.receiver_id = auth.uid())));

drop policy if exists "Participants can confirm own participation" on public.confirmations;
create policy "Participants can confirm own participation" on public.confirmations for insert to authenticated
with check (
  user_id = auth.uid()
  and exists (select 1 from public.transactions t where t.id = transaction_id and (t.payer_id = auth.uid() or t.receiver_id = auth.uid()))
);

drop policy if exists "Participants can read repayments" on public.repayments;
create policy "Participants can read repayments" on public.repayments for select to authenticated
using (exists (select 1 from public.transactions t where t.id = transaction_id and (t.payer_id = auth.uid() or t.receiver_id = auth.uid())));

drop policy if exists "Participants can add repayments" on public.repayments;
create policy "Participants can add repayments" on public.repayments for insert to authenticated
with check (
  created_by = auth.uid()
  and exists (select 1 from public.transactions t where t.id = transaction_id and (t.payer_id = auth.uid() or t.receiver_id = auth.uid()))
);

create or replace function public.create_shared_transaction(
  p_other_email text,
  p_direction text,
  p_amount numeric,
  p_category text,
  p_reason text,
  p_due_date date default null
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  me uuid := auth.uid();
  other_id uuid;
  me_email text;
  new_id uuid;
begin
  if me is null then raise exception 'Please sign in first.'; end if;
  if p_direction not in ('sent','received') then raise exception 'Choose sent or received.'; end if;
  if p_amount is null or p_amount <= 0 then raise exception 'Amount must be greater than zero.'; end if;
  if length(trim(coalesce(p_reason,''))) = 0 then raise exception 'Please enter a reason.'; end if;
  if p_category not in ('Loan','Repayment','Shared expense','Gift','Purchase','Other') then raise exception 'Invalid transaction type.'; end if;

  select id into other_id from public.profiles where lower(email) = lower(trim(p_other_email));
  select lower(email) into me_email from public.profiles where id = me;
  if other_id is null then raise exception 'No HisabBuddy account found for that email. Ask the person to sign up first.'; end if;
  if other_id = me then raise exception 'Choose another person, not your own account.'; end if;

  if p_direction = 'sent' then
    insert into public.transactions (payer_id,receiver_id,payer_email,receiver_email,amount,category,reason,due_date,created_by)
    values (me,other_id,me_email,lower(trim(p_other_email)),p_amount,p_category,trim(p_reason),p_due_date,me)
    returning id into new_id;
  else
    insert into public.transactions (payer_id,receiver_id,payer_email,receiver_email,amount,category,reason,due_date,created_by)
    values (other_id,me,lower(trim(p_other_email)),me_email,p_amount,p_category,trim(p_reason),p_due_date,me)
    returning id into new_id;
  end if;
  return new_id;
end;
$$;

revoke all on function public.create_shared_transaction(text,text,numeric,text,text,date) from public;
grant execute on function public.create_shared_transaction(text,text,numeric,text,text,date) to authenticated;

grant select on public.profiles to authenticated;
grant select on public.transactions to authenticated;
grant select, insert on public.confirmations to authenticated;
grant select, insert on public.repayments to authenticated;

-- Note: this starter version preserves original transactions; it does not expose direct update/delete policies.
-- For production, also add server-side repayment total validation, rate limiting, monitoring and a tested dispute/edit workflow.
